﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TASK_3.BL;
using TASK_3.DL;

namespace TASK_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Cat c1 = new Cat("TOM");
            Cat c2 = new Cat("Thomas");
            Dog d1 = new Dog("Spike");
            Dog d2 = new Dog("puspa");

            AnimalDLcs.Addtollist(c1);
            AnimalDLcs.Addtollist(c2);
            AnimalDLcs.Addtollist(d1);
            AnimalDLcs.Addtollist(d2);

            foreach(Animal i in AnimalDLcs.a)
            {
                Console.WriteLine(i.toString());
                i.greets();
            }
            Console.ReadLine();
        }
    }
}

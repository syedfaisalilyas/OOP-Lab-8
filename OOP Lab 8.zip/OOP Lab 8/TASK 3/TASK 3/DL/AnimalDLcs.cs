﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TASK_3.BL;

namespace TASK_3.DL
{
    class AnimalDLcs
    {
       public static List<Animal> a = new List<Animal>();

        public static void Addtollist(Animal i)
        {
            a.Add(i);
        }
    }
}

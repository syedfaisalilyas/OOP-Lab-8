﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_1.BL;

namespace Task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Cylinder c1 = new Cylinder();
            Cylinder c2 = new Cylinder(5);
            Cylinder c3 = new Cylinder(5, 10, "blue");
            Console.WriteLine(c3.toString());
            c3.setheight(10);
            Console.WriteLine(c3.getvolume());
            Console.ReadLine();
        }


    }
}

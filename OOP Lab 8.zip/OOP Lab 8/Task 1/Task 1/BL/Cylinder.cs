﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1.BL
{
    class Cylinder : Circle
    {
        private double height;

        public Cylinder()
        {
            this.height = 1.0;
        }

        public Cylinder(double radius)
        {
            this.radius = radius;
        }  
        public Cylinder(double radius,double height) : base(radius)
        {
            this.height = height;
        }

        public Cylinder(double radius,double height,string color) : base(radius, color)
        {
            this.height = height;
   
        }

        public double getheight()
        {
            return height;
        }

        public void setheight(double height)
        {
            this.height = height;
        }

        public double getvolume()
        {
            double volume = Math.PI * Math.Pow(radius, 2) * height;
            return volume;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2.DL;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student("Faisal", "122D", "CS", 2022, 80000);
            Student s2 = new Student("jaffer", "122D", "CS", 2022, 80000);
            Staff S1 = new Staff("Jaffer", "517E", "KIPs", 10000000000);
            Staff S2 = new Staff("Faisal", "517E", "KIPs", 10000000);
            PersonDL.addtolist(s1);
            PersonDL.addtolist(s2);
            PersonDL.addtolist(S1);
            PersonDL.addtolist(S2);

            foreach (Person i  in PersonDL.p)
                {
                 Console.WriteLine( i.toString());
              }
            Console.ReadLine();

        }
    }
}

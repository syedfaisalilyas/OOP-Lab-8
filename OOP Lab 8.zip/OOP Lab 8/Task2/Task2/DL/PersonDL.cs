﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2.DL
{
    class PersonDL
    {
      public static List<Person> p = new List<Person>();

        public static void addtolist(Person i)
        {
            p.Add(i);
        }
    }
}

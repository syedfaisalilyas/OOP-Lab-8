﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Student : Person
    {
        private string program;
        private int year;
        private double fees;

        public Student(string name,string address,string program,int year,double fees): base(name, address)
        {
            this.program = program;
            this.year = year;
            this.fees = fees;
        }

        public string getProgram()
        {
            return program;
        }

        public void setprogram(string program)
        {
            this.program = program;
        }

        public int getyear()
        {
            return year;
        }

        public void setyear(int year)
        {
            this.year = year;
        }

        public double getFees()
        {
            return fees;
        }

        public void setFees(double fees)
        {
            this.fees = fees;
        }

        public override string toString()
        {
            return "Student [Person[Name = " + getName() + ",Address = " + getAddress() + ", Program = " + getProgram() + ", Year = " + getyear() + ", Fees = " + getFees() + "]";
        }
    }
}

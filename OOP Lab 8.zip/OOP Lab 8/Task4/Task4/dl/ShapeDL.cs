﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task4.BL;

namespace Task4.dl
{
    class ShapeDL
    {
        public static List<Shape> S = new List<Shape>();

        public static void addtolist(Shape s)
        {
            S.Add(s);
        }
    }
}

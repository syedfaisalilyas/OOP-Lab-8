﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task4.BL;
using Task4.dl;

namespace Task4
{
    class Program
    {
        static void Main(string[] args)
        {

            Rectangle r;
            Console.WriteLine("Enter width :");
            int w = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter height :");
            int h = int.Parse(Console.ReadLine());
            r = new Rectangle(w, h);

            Square s;
            Console.WriteLine("Enter side :");
            int S = int.Parse(Console.ReadLine());
            s = new Square(S);

            Circle c;
            Console.WriteLine("Enter radius :");
            int R = int.Parse(Console.ReadLine());
            c = new Circle(R);

            ShapeDL.addtolist(r); 
            ShapeDL.addtolist(s); 
            ShapeDL.addtolist(c); 

               int  idx = 1;
           foreach(Shape i in ShapeDL.S)
            {
                string message = "The Shape is {0} and its area is {1}";
                message = idx + "." + message;
                Console.WriteLine( message, i.Type() ,i.Area());
                idx++;
            }
            Console.ReadLine();
        }
    }
}
